#include "scaliansudoku.h"
#include "ui_scaliansudoku.h"
#include <QPixmap>
#include <QDebug>

ScalianSudoku::ScalianSudoku(QWidget *parent)
    : QMainWindow(parent)
    , ui(new Ui::ScalianSudoku)
    , sudokuVacio{true}
{
    setWindowFlags(Qt::Window | Qt::WindowTitleHint | Qt::CustomizeWindowHint | Qt::WindowCloseButtonHint | Qt::WindowMinimizeButtonHint);
    ui->setupUi(this);

    ui->FrameCeldas->setVisible(false);

    ui->LogoScalian->setPixmap(QPixmap(":/logo/scalian"));
    ui->LogoCampus->setPixmap(QPixmap(":/logo/campus42"));
    ui->LogoCampus->setScaledContents(true);

    int itemIdx = 0;
    uint filas = ui->Tablero->count();
    for(uint filaId = 0; filaId < filas; filaId++)
    {
        if(auto widget = ui->Tablero->itemAt(filaId)->widget())
        {
            if(widget->objectName().contains("separator"))
            {
                continue;
            }
        }
        auto fila = ui->Tablero->itemAt(filaId)->layout();
        uint celdas = fila->count();
        for(uint celdaId = 0; celdaId < celdas; celdaId++)
        {
            auto celda = dynamic_cast<QLabel*>(fila->itemAt(celdaId)->widget());
            if(not celda)
            {
                continue;
            }

            celda->setText("");
            celda->setProperty("fila", itemIdx/9);
            celda->setProperty("col", itemIdx%9);
            celda->installEventFilter(this);
            itemIdx++;
        }
    }

    connect(ui->botonLimpiar, &QPushButton::clicked, this, &ScalianSudoku::onLimpiarSudoku);
    connect(ui->botonResolver, &QPushButton::clicked, this, &ScalianSudoku::onResolverSudoku);

    connect(ui->Aceptar, &QPushButton::clicked, this, &ScalianSudoku::onAceptar);
    connect(ui->Cancelar, &QPushButton::clicked, this, &ScalianSudoku::onCancelar);
    connect(ui->Borrar, &QPushButton::clicked, this, &ScalianSudoku::onBorrar);
}

int	grid[9][9] = {
	{0, 0, 0, 0, 0, 0, 0, 0, 0},
	{0, 0, 0, 0, 0, 0, 0, 0, 0},
	{0, 0, 0, 0, 0, 0, 0, 0, 0},
	{0, 0, 0, 0, 0, 0, 0, 0, 0},
	{0, 0, 0, 0, 0, 0, 0, 0, 0},
	{0, 0, 0, 0, 0, 0, 0, 0, 0},
	{0, 0, 0, 0, 0, 0, 0, 0, 0},
	{0, 0, 0, 0, 0, 0, 0, 0, 0},
	{0, 0, 0, 0, 0, 0, 0, 0, 0}
};

struct Cell {
	int minPossible;
	int	row;
	int	col;
} nextCell;

void ScalianSudoku::limpiarSudoku()
{
        for (int i = 0; i < 9; i++)
           for (int j = 0; j < 9; j++)
               grid[i][j] = 0;
}

bool ScalianSudoku::findEmptyCell()
{
	for (int row = 0; row < 9; row++)
		for (int col = 0; col < 9; col++)
			if (grid[row][col] == 0)
				return (true);
	return (false);
}

void ScalianSudoku::findMinPossible()
{
	nextCell.minPossible = 9;
	int countAvail = 9;
	for (int row = 0; row < 9; row++)
	{
		for (int col = 0; col < 9; col++)
		{
			if (grid[row][col] == 0)
			{
				for (int i = 0; i < 9; i++)
				{
					{
						if (!isAvailable(row, col, i))
							countAvail--;
					}
				}
				if (countAvail < nextCell.minPossible)
				{
					nextCell.row = row;
					nextCell.col = col;
					nextCell.minPossible = countAvail;
				}
				if (countAvail == 1)
					return;
				countAvail = 9;
			}
		}
	}
}

bool ScalianSudoku::isAvailableCol(int col, int num)
{
	for (int i = 0; i < 9; i++)
		if (grid[i][col] == num)
			return false;
	return (true);
}

bool ScalianSudoku::isAvailableRow(int row, int num)
{
	for (int i = 0; i < 9; i++)
		if (grid[row][i] == num)
			return (false);
	return (true);
}

bool ScalianSudoku::isAvailableGrid(int row, int col, int num)
{
	int startRow;
	int	startCol;

	startRow = row - row % 3;
	startCol = col - col % 3;
	for (int i = 0; i < 3; i++)
		for (int j = 0; j < 3; j++)
			if (grid[i + startRow][j + startCol] == num)
				return (false);
	return (true);
}

bool ScalianSudoku::isAvailable(int row, int col, int num)
{
	return (isAvailableRow(row, num) && isAvailableCol(col, num) && isAvailableGrid(row, col, num));
}

bool ScalianSudoku::isSolvableGrid(int row, int col, int num)
{
	int i, j;
	row *= 3;
	col *= 3;
	for (i = 0; i < 3; i++)
	{
		for (j = 0; j < 3; j++)
		{
			if (grid[row + i][col + j] == 0)
			{
                if ((isAvailableRow(row + i, num) && isAvailableCol(col + j, num))
					|| !isAvailableGrid(row, col, num))
					return (true);
			}
			else if (grid[row + i][col + j] == num)
				return (true);
		}
	}
	return (false);
}

bool ScalianSudoku::isSolvable()
{
	for (int row = 0; row < 3; row++)
	{
		for (int col = 0; col < 3; col++)
		{
			for (int num = 1; num < 10; num++)
				if (!isSolvableGrid(row, col, num))
                {
                    return (false);
                }
         }
	}
	return (true);
}

void ScalianSudoku::printSudoku()
{
	for (int i = 0; i < 9; i++)
		for (int j = 0; j < 9; j++)
			escribirCelda(grid[i][j], i, j, Qt::GlobalColor::black);
}

int ScalianSudoku::verifyInput()
{
    int cluesCount = 0;

	for (int i = 0; i < 9; i++)
	{
		for (int j = 0; j < 9; j++)
		{
			if (grid[i][j] != 0)
			{
                cluesCount++;
				if (!checkCorrect(i, j, grid[i][j]))
                {
                    return (0);
                }
            }
		}
	}
    return (cluesCount);
}

bool ScalianSudoku::solveSudoku()
{
	int	row, col;
	if (!findEmptyCell())
		return (true);
	findMinPossible();
	row = nextCell.row;
	col = nextCell.col;
	for (int num = 1; num <= 9; num++)
	{
		if (isAvailable(row, col, num))
		{
			grid[row][col] = num;
            escribirCelda(num, row, col, Qt::GlobalColor::black);
			if (solveSudoku())
				return (true);
			grid[row][col] = 0;
		}
	}
	return (false);
}

void ScalianSudoku::resolverSudoku()
{
	if (solveSudoku())
		printSudoku();
}

bool ScalianSudoku::checkCorrect(int row, int col, int num)
{
	int startRow;
	int	startCol;

	startRow = row - row % 3;
	startCol = col - col % 3;
	for (int i = 0; i < 9; i++)
		if (grid[row][i] == num && i != col)
			return (false);
	for (int i = 0; i < 9; i++)
		if (grid[i][col] == num && i != row)
			return (false);
	for (int i = 0; i < 3; i++)
	{
		for (int j = 0; j < 3; j++)
		{
			if ((i + startRow) != row && (j + startCol) != col)
				if (grid[i + startRow][j + startCol] == num)
					return (false);
		}
	}
	return (true);
}

bool ScalianSudoku::chequearSudoku()
{
	for (int i = 0; i < 9; i++)
	{
		for (int j = 0; j < 9; j++)
		{
			if (!checkCorrect(i, j, grid[i][j]))
				return (false);
		}
	}
    return (true);
}

void ScalianSudoku::setearCelda(uint filaId, uint colId, uint valor)
{
	escribirCelda(valor, filaId, colId, Qt::GlobalColor::black);
	grid[filaId][colId] = valor;
}

void ScalianSudoku::borrarCelda(uint filaId, uint colId)
{
	limpiarCelda(filaId, colId);
    grid[filaId][colId] = 0;
}

ScalianSudoku::~ScalianSudoku()
{
    delete ui;
}

void ScalianSudoku::onDobleClickEnCelda(uint filaId, uint colId)
{
    ui->FrameCeldas->setProperty("fila", filaId);
    ui->FrameCeldas->setProperty("col", colId);

    ui->EtiquetaFila->setText(QString::number(filaId));
    ui->EtiquetaColumna->setText(QString::number(colId));
    ui->FrameCeldas->setVisible(true);
    ui->FrameControles->setVisible(false);
}

std::optional<QLabel*> ScalianSudoku::obtenerCelda(uint filaId, uint colId)
{
    if(filaId > 9 || colId > 9)
    {
        return std::nullopt;
    }

    if(colId > 5)
    {
        colId += 2;
    }
    else if(colId > 2)
    {
        colId += 1;
    }

    if(filaId > 5)
    {
        filaId += 2;
    }
    else if(filaId > 2)
    {
        filaId += 1;
    }

    auto fila = ui->Tablero->itemAt(filaId)->layout();
    auto celda = dynamic_cast<QLabel*>(fila->itemAt(colId)->widget());

    if(not celda)
    {
        return std::nullopt;
    }

    return celda;
}

bool ScalianSudoku::limpiarCelda(uint filaId, uint colId)
{
    auto celda = obtenerCelda(filaId, colId);
    if(celda.has_value())
    {
        QColor color(Qt::GlobalColor::black);
        celda.value()->setStyleSheet(QString("QLabel { color : rgb(%1,%2,%3); }").arg(color.red()).arg(color.green()).arg(color.blue()));
        celda.value()->setText("");
        return true;
    }

    return false;
}

bool ScalianSudoku::escribirCelda(uint valor, uint filaId, uint colId, QColor color)
{
    auto celda = obtenerCelda(filaId, colId);
    if(celda.has_value() && valor < 10)
    {
        celda.value()->setStyleSheet(QString("QLabel { color : rgb(%1,%2,%3); }").arg(color.red()).arg(color.green()).arg(color.blue()));
        celda.value()->setText(QString::number(valor));
        return true;
    }

    return false;
}

void ScalianSudoku::escribirResultado(const std::string &resultado, QColor color)
{
    ui->EtiquetaResultado->setStyleSheet(QString("QLabel { color : rgb(%1,%2,%3); }").arg(color.red()).arg(color.green()).arg(color.blue()));
    ui->EtiquetaResultado->setText(resultado.c_str());
}

void ScalianSudoku::onLimpiarSudoku()
{
    for(uint filaId = 0; filaId < 9; filaId++)
    {
        for(uint colId = 0; colId < 9; colId++)
        {
            limpiarCelda(filaId, colId);
        }
    }

    escribirResultado("");
    limpiarSudoku();
}

void ScalianSudoku::onResolverSudoku()
{
    bool resultado;
    int inputSize;

    if (findEmptyCell())
	{
        inputSize = verifyInput();
        if (inputSize >= 17 &&  isSolvable())
                resolverSudoku();
        else
        {
            escribirResultado("Imposible", QColor(Qt::GlobalColor::red));
            return ;
        }
	}
    resultado = chequearSudoku();
    if (resultado)
        escribirResultado("Correcto", QColor(Qt::GlobalColor::green));
    else
        escribirResultado("Incorrecto", QColor(Qt::GlobalColor::yellow));
}

void ScalianSudoku::onAceptar()
{
    uint fila = ui->FrameCeldas->property("fila").value<uint>();
    uint col = ui->FrameCeldas->property("col").value<uint>();
    uint valor = ui->ValorCelda->value();
    ui->FrameCeldas->setVisible(false);
    ui->FrameControles->setVisible(true);
    setearCelda(fila, col, valor);
}

void ScalianSudoku::onCancelar()
{
    ui->FrameCeldas->setVisible(false);
    ui->FrameControles->setVisible(true);
}

void ScalianSudoku::onBorrar()
{
    uint fila = ui->FrameCeldas->property("fila").value<uint>();
    uint col = ui->FrameCeldas->property("col").value<uint>();
    ui->FrameCeldas->setVisible(false);
    ui->FrameControles->setVisible(true);
    limpiarCelda(fila, col);
    borrarCelda(fila, col);
}

bool ScalianSudoku::eventFilter(QObject *object, QEvent *event)
{
    if(event->type() == QEvent::MouseButtonDblClick)
    {
        if(sudokuVacio)
        {
            auto coordinates = obtenerCoordenadas(object);
            if(coordinates.has_value())
            {
                uint fila = std::get<0>(coordinates.value());
                uint col = std::get<1>(coordinates.value());
                onDobleClickEnCelda(fila, col);
            }
        }
        else
        {
            // Popup
        }
    }

    return QMainWindow::eventFilter(object, event);
}

std::optional<std::tuple<uint, uint>> ScalianSudoku::obtenerCoordenadas(QObject *object)
{
    if(object)
    {
        auto label = dynamic_cast<QLabel*>(object);
        if(label)
        {
            uint fila = object->property("fila").value<uint>();
            uint col = object->property("col").value<uint>();
            return std::tuple<int,int>{fila,col};
        }
    }

    return std::nullopt;
}

